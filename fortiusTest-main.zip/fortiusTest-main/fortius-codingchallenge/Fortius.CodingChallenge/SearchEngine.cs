﻿using System.Collections.Generic;
using System.Linq;

namespace ConstructionLine.CodingChallenge
{
    public class SearchEngine
    {
        private readonly List<Shirt> _shirts;

        public SearchEngine(List<Shirt> shirts)
        {
            _shirts = shirts;

        }


        public SearchResults Search(SearchOptions options)
        {
            var shirts = _shirts.Where(s => (!options.Colors.Select(c => c.Id).Any() || options.Colors.Select(c => c.Id).Contains(s.Color.Id)) && (!options.Sizes.Select(c => c.Id).Any() || options.Sizes.Select(size => size.Id).Contains(s.Size.Id))).ToList();

            var colorCounts = Color.All.Select(c => new ColorCount() { Color = c, Count = 0 }).ToList();
            var sizeCounts = Size.All.Select(c => new SizeCount() { Size = c, Count = 0 }).ToList();
            var searchResults = new SearchResults
            {
                Shirts = shirts,
                ColorCounts = colorCounts,
                SizeCounts = sizeCounts,
            };

            return shirts.Aggregate(searchResults, (final, current) =>
            {
                final.ColorCounts.Single(c => c.Color.Id == current.Color.Id).Count++;
                final.SizeCounts.Single(s => s.Size.Id == current.Size.Id).Count++;
                return final;
            });
        }
    }
}